#include<iostream>
#include<SFML/Graphics.hpp>
#include<string>
using namespace std;
int main() {
	sf::Window window(sf::VideoMode(800, 600),"Events");
	string buffer;
	int l, k, i;
	while(window.isOpen()) {
		sf::Event event;
		while (window.pollEvent(event)) {
			if (event.type == sf::Event::EventType::KeyPressed && event.key.code == sf::Keyboard::Key::Escape) {
				window.close();
			}
			if (event.type == sf::Event::EventType::KeyPressed && event.key.code == sf::Keyboard::Key::Space) {
				buffer += "_";
			}
			if (event.type == sf::Event::EventType::TextEntered) {
				buffer += event.text.unicode;
				window.setTitle(buffer);
			}
			if (event.type == sf::Event::EventType::KeyPressed && event.key.code == sf::Keyboard::Key::Backspace) {
				buffer.erase(prev(buffer.end()));
				if (buffer.length() != 0) {
					buffer.resize(buffer.size() - 1);
				}
				window.setTitle(buffer);
			}
			window.display();
		}
	}
}